package com.example.propertychild_row_column2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
